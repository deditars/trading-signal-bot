
# bot.py
import yfinance as yf
import pandas as pd
import time
from ta.momentum import RSIIndicator
from ta.trend import MACD, SMAIndicator
import telegram
import os

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "me")
ASSETS = os.getenv("ASSETS", "EURUSD=X,XAUUSD=X,GBPUSD=X,BTC-USD").split(",")

bot = telegram.Bot(token=TELEGRAM_TOKEN)
last_signals = {}

def fetch_signals(symbol):
    df = yf.download(symbol, period="1d", interval="5m")
    if df.empty:
        return None
    df.dropna(inplace=True)
    df["MA5"] = SMAIndicator(df["Close"], window=5).sma_indicator()
    df["MA20"] = SMAIndicator(df["Close"], window=20).sma_indicator()
    df["RSI"] = RSIIndicator(df["Close"], window=14).rsi()
    macd = MACD(df["Close"])
    df["MACD"] = macd.macd()
    df["Signal"] = macd.macd_signal()
    last = df.iloc[-1]

    signal = "WAIT"
    if last["MA5"] > last["MA20"] and last["RSI"] < 70 and last["MACD"] > last["Signal"]:
        signal = "BUY"
    elif last["MA5"] < last["MA20"] and last["RSI"] > 30 and last["MACD"] < last["Signal"]:
        signal = "SELL"
    return signal, last

while True:
    for asset in ASSETS:
        try:
            result = fetch_signals(asset)
            if result is None:
                continue
            signal, last = result
            if asset not in last_signals or signal != last_signals[asset]:
                msg = f"📈 Sinyal {asset}\nSinyal: {signal}\nMA5: {last['MA5']:.4f}\nMA20: {last['MA20']:.4f}\nRSI: {last['RSI']:.2f}\nMACD: {last['MACD']:.4f} > Signal: {last['Signal']:.4f}"
                bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=msg)
                last_signals[asset] = signal
        except Exception as e:
            print(f"Error for {asset}:", e)
    time.sleep(60)
